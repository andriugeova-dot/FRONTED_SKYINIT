/// <reference types="astro/client" />
